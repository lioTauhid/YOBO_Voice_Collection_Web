# YOBO_Voice_Collection_Web

## Description

This is an implementation of capturing voice from web page and send it to web server. A simple web page includes html,css,java-script can record user voice, display/play/download voice files, and then upload/save it to a flask web server.

## Use case
If you need to collect voice data from user then it will be helpfull.

## Install
This project runs with Python. Also install dependencies listed to requirements.py by following command :
* pip install -r requirements.txt

## Usage
1. Start the main.py
2. Go to "http://&lt;address&gt;:&lt;port&gt;/"
3. See the result in the browser
